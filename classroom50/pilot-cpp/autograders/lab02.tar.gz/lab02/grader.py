"""Instructor-side formative grader. Student C++ only runs inside Docker.

The image must already be pulled and pinned by digest. Reference answers stay in
this trusted process; neither container receives the tests or expected values.
This is a small supervised pilot, not a hostile multi-tenant grading service.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import math
from pathlib import Path
import re
import stat
import subprocess
import tempfile
import threading
import time
import uuid


SCHEMA = "nltu.pilot-result.v1"
REL_TOL = 1e-5
ABS_TOL = 1e-6
SOURCE_LIMIT = 256 * 1024
OUTPUT_LIMIT = 64 * 1024
COMPILE_TIMEOUT = 30
EXECUTION_TIMEOUT = 3
CASES = {
    1: (
        (5.8, 7.068995285213936), (5.8001, 7.068644059577792),
        (6.0, 6.466182933713737), (6.25, 5.944936052197017),
        (7.0, 5.255154091198163), (7.5, 4.884671672771191),
        (8.0, 4.16722270842005), (9.0, 2.3233880803560947),
        (10.0, 1.3637343931462806), (10.5999, 1.122383773658363),
        (10.6, 1.1223545345113437),
    ),
    # Independently calculated at 70 decimal digits using Decimal.ln and a
    # Newton cube root. The test suite repeats that independent calculation.
    2: (
        (0.4, 0.23931718889960424), (0.4001, 0.23930943315126532),
        (0.5, 0.23684229184739147), (0.75, 0.23909434934976073),
        (1.0, 0.27358220739458966), (1.5, 0.517662963445183),
        (2.0, 0.9613054388828332), (3.0, 2.0699973564079612),
        (4.5, 3.5112977051967396), (6.2999, 4.6626542420771),
        (6.3, 4.662704724777317),
    ),
}
DOMAINS = {1: "[5.8, 10.6]", 2: "[0.4, 6.3]"}


def read_result(output: str) -> float:
    """Permit diagnostic lines, but require exactly one well-formed result."""
    lines = [line for line in output.splitlines()
             if re.match(r"^Result[ \t]*=", line)]
    if len(lines) != 1:
        raise ValueError("Expected exactly one line: Result = <number>")
    match = re.fullmatch(r"Result[ \t]*=[ \t]*(\S+)[ \t]*", lines[0])
    if match is None:
        raise ValueError("Malformed result line")
    token = match[1]
    if len(token) > 64:
        raise ValueError("Result number is too long")
    try:
        value = float(token)
    except ValueError:
        raise ValueError("Result must be a number") from None
    if not math.isfinite(value):
        raise ValueError("Result must be finite (not NaN or infinity)")
    if not re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", token):
        raise ValueError("Result must use decimal or scientific notation")
    return value


def matches_reference(actual: float, expected: float) -> bool:
    return math.isfinite(actual) and math.isclose(
        actual, expected, rel_tol=REL_TOL, abs_tol=ABS_TOL)


def validate_image(image: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]*@sha256:[0-9a-f]{64}", image):
        raise ValueError("Image must be an instructor-approved name@sha256:<64 lowercase hex digits>")
    return image


def docker_command(image: str, name: str, source: Path | None,
                   binary_dir: Path, *, compile_program: bool) -> list[str]:
    """Construct argv without a shell, student flags, scripts, or environment."""
    validate_image(image)
    paths = [binary_dir] + ([source] if source is not None else [])
    if any("," in str(path) for path in paths):
        raise ValueError("Staging paths cannot contain commas")
    memory = "512m" if compile_program else "128m"
    command = [
        "docker", "run", "--rm", "--pull=never", "--name", name,
        "--network", "none", "--cap-drop", "ALL",
        "--security-opt", "no-new-privileges", "--read-only",
        "--user", "65534:65534", "--cpus", "1", "--memory", memory,
        "--memory-swap", memory, "--pids-limit", "64" if compile_program else "16",
        "--ulimit", "fsize=16777216:16777216", "--ulimit", "core=0:0",
        "--log-driver", "none", "--init",
        "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,size=64m,mode=1777", "--interactive",
    ]
    if compile_program:
        if source is None:
            raise ValueError("Compilation requires a staged source file")
        command += [
            "--mount", f"type=bind,source={source},target=/submission/main.cpp,readonly",
            "--mount", f"type=bind,source={binary_dir},target=/out",
            "--workdir", "/tmp", "--entrypoint", "g++", image,
            "-std=c++17", "-O0", "-Wall", "-Wextra", "-pedantic",
            "/submission/main.cpp", "-o", "/out/program",
        ]
    else:
        command += [
            "--mount", f"type=bind,source={binary_dir},target=/program,readonly",
            "--workdir", "/tmp", "--entrypoint", "/program/program", image,
        ]
    return command


@dataclass
class ContainerResult:
    exit_code: int | None = None
    stdout: str = ""
    stderr: str = ""
    timed_out: bool = False
    output_limited: bool = False
    infrastructure_error: bool = False
    cleanup_failed: bool = False


def remove_container(name: str) -> bool:
    """Bound cleanup time too. Output from the Docker daemon is not forwarded."""
    try:
        completed = subprocess.run(
            ["docker", "rm", "--force", name], stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=5, check=False,
        )
        return completed.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def run_container(command: list[str], name: str, *, timeout: float,
                  input_bytes: bytes = b"", output_limit: int = OUTPUT_LIMIT) -> ContainerResult:
    """Read bounded buffers concurrently; never use unbounded communicate()."""
    result = ContainerResult()
    buffers = {"stdout": bytearray(), "stderr": bytearray()}
    lock = threading.Lock()
    overflow = threading.Event()
    readers: list[threading.Thread] = []
    process = None
    aborted = False

    def consume(pipe, key):
        try:
            while True:
                chunk = pipe.read(4096)
                if not chunk:
                    break
                with lock:
                    remaining = max(0, output_limit - sum(map(len, buffers.values())))
                    buffers[key].extend(chunk[:remaining])
                    if len(chunk) > remaining:
                        overflow.set()
                # Keep draining after overflow until forced cleanup closes the
                # pipe. The buffers never grow beyond their shared byte limit.
        except (OSError, ValueError):
            pass

    try:
        process = subprocess.Popen(
            command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, bufsize=0,
        )
        for key in ("stdout", "stderr"):
            thread = threading.Thread(target=consume, args=(getattr(process, key), key), daemon=True)
            readers.append(thread)
            thread.start()
        try:
            process.stdin.write(input_bytes)
            process.stdin.close()
        except (BrokenPipeError, OSError):
            pass
        deadline = time.monotonic() + timeout
        while process.poll() is None:
            if overflow.is_set():
                aborted = True
                break
            if time.monotonic() >= deadline:
                result.timed_out = True
                aborted = True
                break
            time.sleep(0.01)
    except OSError:
        result.infrastructure_error = True
    finally:
        # A Docker client timeout/kill alone does not stop its container.
        removed = remove_container(name)
        result.cleanup_failed = aborted and not removed
        if process is not None:
            if process.poll() is None:
                process.kill()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                result.infrastructure_error = True
            result.exit_code = process.returncode
            # Docker uses 125 for container launch failure, 126 when the
            # command cannot be invoked, and 127 when it cannot be found.
            # Student programs returning these codes are conservatively sent
            # for instructor rerun because the CLI alone cannot distinguish.
            if result.exit_code in (125, 126, 127):
                result.infrastructure_error = True
            for reader in readers:
                reader.join(timeout=2)
            if any(reader.is_alive() for reader in readers):
                result.infrastructure_error = True
            else:
                process.stdout.close()
                process.stderr.close()
        result.output_limited = overflow.is_set()
        with lock:
            result.stdout = bytes(buffers["stdout"]).decode("utf-8", errors="replace")
            result.stderr = bytes(buffers["stderr"]).decode("utf-8", errors="replace")
    return result


def failure_detail(result: ContainerResult) -> str | None:
    if result.cleanup_failed:
        return "Container cleanup was not confirmed; instructor investigation required"
    if result.infrastructure_error:
        return "Grading infrastructure failed; instructor rerun required"
    if result.timed_out:
        return "Time limit exceeded"
    if result.output_limited:
        return "Output limit exceeded"
    if result.exit_code != 0:
        return f"Program exit code: {result.exit_code}"
    return None


def clean_diagnostic(text: str) -> str:
    """Bound and remove terminal controls from diagnostics stored for students."""
    return "".join(char for char in text if char in "\n\t" or ord(char) >= 32)[:OUTPUT_LIMIT]


def write_results(result: dict, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    (output / "result.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=True, allow_nan=False) + "\n", encoding="utf-8")
    rows = []
    for check in result["checks"]:
        actual = "--" if check["actual"] is None else f'{check["actual"]:.10g}'
        rows.append(f'| {check["input"]:g} | {check["expected"]:.10g} | {actual} | '
                    f'{"PASS" if check["passed"] else "FAIL"} | {check["detail"]} |')
    report = [
        "# Lab 02 - Ready submission feedback", "",
        f'Variant **{result["variant_id"]}**: **{result["passed"]}/{result["total"]} checks passed**.',
        f'Status: `{result["status"]}`.', "",
        "This is formative feedback. It awards no final marks and does not prove authorship.",
        "Flowcharts, reports, student-designed tests and oral defense still require instructor review.", "",
        f'Only valid inputs in {DOMAINS[result["variant_id"]]} are assessed. '
        f"Relative tolerance: {REL_TOL:g}; absolute tolerance: {ABS_TOL:g}.", "",
        "| Input x | Expected | Actual | Check | Detail |",
        "| --- | --- | --- | --- | --- |", *rows, "",
    ]
    if not rows:
        report += ["No program checks ran. See the compilation or infrastructure details below.", ""]
    compilation = result["compilation"]
    if compilation.get("detail"):
        report += ["Compilation: " + compilation["detail"], ""]
    diagnostics = "\n".join(filter(None, [compilation.get("stdout"), compilation.get("stderr")]))
    if diagnostics:
        # Keep PR feedback well below GitHub comment limits, even when a
        # submitted #error message contains a long sequence of backticks.
        if len(diagnostics) > 8000:
            diagnostics = diagnostics[:8000] + "\n[Diagnostics truncated; see result.json.]"
        fence = "`" * max(3, 1 + max((len(m[0]) for m in re.finditer(r"`+", diagnostics)), default=0))
        report += ["Compiler diagnostics (bounded):", "", fence + "text", diagnostics, fence, ""]
    report += [f'Execution image: `{result["execution"]["image"]}`.', ""]
    (output / "report.md").write_text("\n".join(report), encoding="utf-8")


def grade_submission(source: Path, variant: int, output: Path, image: str,
                     *, runner=None) -> dict:
    validate_image(image)
    if variant not in CASES:
        raise ValueError("This pilot supports variants 1 and 2 only")
    runner = runner or run_container
    result = {
        "schema": SCHEMA, "variant_id": variant, "status": "execution_error",
        "infrastructure_error": False,
        "passed": 0, "total": len(CASES[variant]), "checks": [],
        "compilation": {},
        "execution": {"image": image, "timeout_seconds_per_case": EXECUTION_TIMEOUT,
                      "output_limit_bytes": OUTPUT_LIMIT, "network": "none"},
    }
    try:
        info = source.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_size > SOURCE_LIMIT:
            raise ValueError("Submission must be one regular C++ source file, at most 256 KiB")
        with tempfile.TemporaryDirectory(prefix="nltu-lab02-") as staging:
            staging_dir = Path(staging)
            staging_dir.chmod(0o755)
            staged_source = staging_dir / "main.cpp"
            with source.open("rb") as stream:
                source_bytes = stream.read(SOURCE_LIMIT + 1)
            if len(source_bytes) > SOURCE_LIMIT:
                raise ValueError("Submission exceeds the 256 KiB source limit")
            staged_source.write_bytes(source_bytes)
            staged_source.chmod(0o444)
            binary_dir = staging_dir / "bin"
            binary_dir.mkdir(mode=0o777)
            binary_dir.chmod(0o777)
            compile_name = "nltu-compile-" + uuid.uuid4().hex
            compiled = runner(
                docker_command(image, compile_name, staged_source, binary_dir, compile_program=True),
                compile_name, timeout=COMPILE_TIMEOUT,
            )
            detail = failure_detail(compiled)
            result["compilation"] = {
                "exit_code": compiled.exit_code, "stdout": clean_diagnostic(compiled.stdout),
                "stderr": clean_diagnostic(compiled.stderr), "timed_out": compiled.timed_out,
                "output_limited": compiled.output_limited, "detail": detail,
            }
            if detail:
                result["infrastructure_error"] = compiled.infrastructure_error or compiled.cleanup_failed
                result["status"] = ("execution_error" if compiled.infrastructure_error or compiled.cleanup_failed
                                    else "compile_error")
            else:
                program = binary_dir / "program"
                binary_info = program.lstat()
                if not stat.S_ISREG(binary_info.st_mode) or binary_info.st_size > 16 * 1024 * 1024:
                    raise ValueError("Compiler did not produce a bounded regular executable")
                # A new container receives one input on stdin. It sees only the
                # compiled staging directory, never the instructor's checkout.
                execution_failed = False
                for x, expected in CASES[variant]:
                    name = "nltu-run-" + uuid.uuid4().hex
                    executed = runner(
                        docker_command(image, name, None, binary_dir, compile_program=False),
                        name, timeout=EXECUTION_TIMEOUT, input_bytes=f"{x:.15g}\n".encode("ascii"),
                    )
                    actual, passed = None, False
                    detail = failure_detail(executed)
                    if detail is not None:
                        execution_failed = True
                    else:
                        try:
                            actual = read_result(executed.stdout)
                            passed = matches_reference(actual, expected)
                            detail = "Within tolerance" if passed else "Value differs from the assigned variant"
                        except ValueError as error:
                            detail = str(error)
                            execution_failed = True
                    result["checks"].append({"input": x, "expected": expected, "actual": actual,
                                             "passed": passed, "detail": detail})
                    result["passed"] += int(passed)
                    if executed.infrastructure_error or executed.cleanup_failed:
                        result["infrastructure_error"] = True
                        # Do not launch another container when cleanup or the
                        # execution service has failed.
                        break
                result["status"] = ("passed" if result["passed"] == result["total"] else
                                    "execution_error" if execution_failed else "failed")
    except (OSError, ValueError) as error:
        result["status"] = "execution_error"
        result["infrastructure_error"] = True
        # Never include arbitrary source text or unbounded exception messages.
        result["compilation"]["detail"] = (str(error)[:180] if isinstance(error, ValueError)
                                             else "Source staging or executable inspection failed")
    write_results(result, output)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--variant", required=True, type=int, choices=sorted(CASES))
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--image", required=True)
    args = parser.parse_args()
    try:
        validate_image(args.image)
    except ValueError as error:
        parser.error(str(error))
    result = grade_submission(args.source, args.variant, args.output, args.image)
    print(f'Variant {args.variant}: {result["status"]}; {result["passed"]}/{result["total"]} checks passed')
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
