"""Native Classroom 50 adapter for formative C++ Lab 02 numerical checks.

Install beside grader.py, runtime.json and public-variants.json in the published
assignment bundle. This file is teacher code, never copied from student source.
"""

from __future__ import annotations

from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request


SCHEMA = "classroom50/result/v1"
MAP_SCHEMA = "nltu.classroom50-public-variants.v1"
LOGIN = re.compile(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?")
IMAGE = re.compile(r"gcc:[A-Za-z0-9_.-]+@sha256:[a-f0-9]{64}")


def load_variant_map(path: Path) -> dict[str, int]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if (not isinstance(data, dict) or set(data) != {"schema", "variants_by_github_id"}
            or data.get("schema") != MAP_SCHEMA):
        raise ValueError("Викладач має перевірити перелік призначених варіантів")
    mapping = data.get("variants_by_github_id")
    if not isinstance(mapping, dict) or not mapping:
        raise ValueError("Викладач має призначити варіанти учасникам")
    for user_id, variant in mapping.items():
        if not re.fullmatch(r"[1-9][0-9]*", user_id) or type(variant) is not int or variant not in (1, 2):
            raise ValueError("Перевірте облікові записи та номери варіантів у налаштуваннях")
    return mapping


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, newurl):
        raise ValueError("Не вдалося підтвердити обліковий запис GitHub")


def resolve_owner_id(owner: str) -> int:
    """Read the source repository owner's account; never use the rerun actor."""
    if not LOGIN.fullmatch(owner):
        raise ValueError("Не вдалося визначити власника роботи")
    request = urllib.request.Request(
        "https://api.github.com/users/" + owner,
        headers={"Accept": "application/vnd.github+json", "User-Agent": "NLTU-C50-pilot",
                 "X-GitHub-Api-Version": "2022-11-28"},
    )
    # No teacher service token is needed. A failed/rate-limited read stops the
    # run rather than selecting a default variant. This is enough for a demo.
    with urllib.request.build_opener(NoRedirect()).open(request, timeout=15) as response:
        payload = response.read(65537)
    if len(payload) > 65536:
        raise ValueError("Не вдалося прочитати дані облікового запису")
    account = json.loads(payload)
    if (account.get("type") != "User" or not isinstance(account.get("login"), str)
            or account["login"].casefold() != owner.casefold()
            or type(account.get("id")) is not int or account["id"] <= 0):
        raise ValueError("GitHub не підтвердив обліковий запис власника роботи")
    return account["id"]


def select_variant(environment: dict[str, str], mapping: dict[str, int], resolver=resolve_owner_id) -> tuple[str, int]:
    if environment.get("ASSIGNMENT_TYPE") != "individual":
        raise ValueError("Цей приклад призначений для індивідуальних робіт")
    owner = environment.get("OWNER") or environment.get("USERNAME", "")
    username = environment.get("USERNAME")
    if username and owner.casefold() != username.casefold():
        raise ValueError("Дані власника роботи не збігаються")
    if not LOGIN.fullmatch(owner):
        raise ValueError("Не вдалося визначити власника роботи")
    user_id = resolver(owner)
    if type(user_id) is not int or str(user_id) not in mapping:
        raise ValueError("Для цього облікового запису не призначено варіант. Зверніться до викладача")
    return owner, mapping[str(user_id)]


def to_classroom_result(pilot: dict, environment: dict[str, str], owner: str, variant: int) -> dict:
    if pilot.get("schema") != "nltu.pilot-result.v1" or pilot.get("variant_id") != variant:
        raise ValueError("Результат перевірки не відповідає призначеному варіанту")
    if pilot.get("infrastructure_error") is True:
        raise ValueError("Технічна помилка. Викладач має повторити перевірку")
    if pilot.get("status") not in ("passed", "failed", "compile_error", "execution_error"):
        raise ValueError("Не вдалося визначити стан перевірки")
    total, passed, checks = pilot.get("total"), pilot.get("passed"), pilot.get("checks")
    if (type(total) is not int or not 1 <= total <= 100 or type(passed) is not int
            or not isinstance(checks, list) or len(checks) > total):
        raise ValueError("Не вдалося підтвердити кількість перевірок")
    tests = []
    for index, check in enumerate(checks):
        if not isinstance(check, dict) or type(check.get("passed")) is not bool:
            raise ValueError("Отримано некоректний результат перевірки")
        for key in ("input", "expected", "actual"):
            value = check.get(key)
            if key == "actual" and value is None:
                continue
            if type(value) not in (int, float) or not math.isfinite(value):
                raise ValueError("Отримано некоректне числове значення")
        tests.append({
            "test-name": f"Варіант {variant}: вхідне число {check['input']:g}",
            "passed": check["passed"], "score": int(check["passed"]), "max-score": 1,
            "input": check["input"], "expected": check["expected"], "actual": check.get("actual"),
            "detail": str(check.get("detail", ""))[:500], "purpose": "Навчальна перевірка",
        })
    if passed != sum(test["score"] for test in tests):
        raise ValueError("Кількість правильних результатів не збігається з даними перевірки")
    if pilot["status"] == "passed" and passed != total:
        raise ValueError("Перевірку ще не завершено")
    while len(tests) < total:
        tests.append({"test-name": f"Варіант {variant}: перевірку {len(tests) + 1} не виконано",
                      "passed": False, "score": 0, "max-score": 1,
                      "detail": "Числового результату немає. Перегляньте повідомлення про помилки.",
                      "purpose": "Навчальна перевірка"})
    required = ("CLASSROOM", "ASSIGNMENT", "SUBMISSION_TAG", "COMMIT_URL", "RELEASE_URL")
    if any(not environment.get(key) for key in required):
        raise ValueError("Не вдалося отримати дані надісланої роботи")
    if not environment["SUBMISSION_TAG"].startswith("submit/"):
        raise ValueError("Роботу ще не надіслано на перевірку")
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return {
        "schema": SCHEMA, "classroom": environment["CLASSROOM"], "assignment": environment["ASSIGNMENT"],
        "assignment_type": "individual", "owner": owner, "submission": environment["SUBMISSION_TAG"],
        "commit": environment["COMMIT_URL"], "release": environment["RELEASE_URL"],
        "review": environment.get("REVIEW_URL") or environment["COMMIT_URL"],
        # The native runner replaces these with its submission/grade times.
        "datetime": now, "graded_at": now, "score": passed, "max-score": total, "tests": tests,
    }


def clean_environment() -> dict[str, str]:
    # Docker host access belongs only to the trusted grader process. Student
    # containers receive no environment credentials or Docker socket.
    keys = ("PATH", "HOME", "TMPDIR", "TEMP", "TMP", "SYSTEMROOT", "DOCKER_HOST",
            "DOCKER_CONTEXT", "DOCKER_CONFIG", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH")
    return {key: os.environ[key] for key in keys if key in os.environ}


LAB_FILES = {1: "lab1.cpp", 2: "lab2.cpp"}
SHA = re.compile(r"[a-fA-F0-9]{40}")


def selected_labs(environment: dict[str, str], workspace: Path) -> list[int]:
    """Diff the whole pushed range; unavailable history checks both labs."""
    if environment.get("GITHUB_EVENT_NAME") != "push":
        return [1, 2]
    try:
        event = json.loads(Path(environment["GITHUB_EVENT_PATH"]).read_text(encoding="utf-8"))
        before, after = event.get("before", ""), environment.get("GITHUB_SHA", "")
        if event.get("ref", "").startswith("refs/tags/"):
            return [1, 2]
        if not SHA.fullmatch(before) or not SHA.fullmatch(after) or before == "0" * 40:
            return [1, 2]
        changed = subprocess.run(
            ["git", "-C", str(workspace), "diff", "--no-ext-diff", "--no-textconv",
             "--name-only", "-z", "--no-renames", before, after, "--", *LAB_FILES.values()],
            check=True, capture_output=True, timeout=30, env=clean_environment(),
        ).stdout.decode("utf-8").split("\0")
        return [lab for lab, name in LAB_FILES.items() if name in changed]
    except (OSError, ValueError, KeyError, subprocess.SubprocessError):
        return [1, 2]


def combine_results(pilots: dict[int, dict], reports: dict[int, str], environment: dict[str, str],
                    owner: str, variant: int) -> tuple[dict, str]:
    if not pilots:
        empty = {"schema": "nltu.pilot-result.v1", "variant_id": variant, "status": "compile_error",
                 "total": 1, "passed": 0, "checks": []}
        combined = to_classroom_result(empty, environment, owner, variant)
        combined.update({"score": 0, "max-score": 0, "tests": []})
        return combined, ("# Лабораторні не змінено\n\n"
                          "Числові перевірки не запускалися. Цей запуск не виставляє оцінку за предмет.\n\n"
                          f"[Збережена версія коду]({environment['COMMIT_URL']})\n")
    native = []
    for lab, pilot in pilots.items():
        result = to_classroom_result(pilot, environment, owner, variant)
        for test in result["tests"]:
            test["test-name"] = f"Лабораторна №{lab}: " + test["test-name"]
        native.append(result)
    combined = dict(native[0])
    combined["score"] = sum(result["score"] for result in native)
    combined["max-score"] = sum(result["max-score"] for result in native)
    combined["tests"] = [test for result in native for test in result["tests"]]
    names = ", ".join(f"№{lab}" for lab in pilots)
    report = ["# Автоматична перевірка лабораторних робіт", "",
              f"**У цьому запуску перевірено тільки лабораторні: {names}.**", "",
              "Це результат останніх змін, а не підсумкова оцінка за весь предмет. "
              "Раніше здані роботи у цей результат не входять.", "",
              f"Варіант **{variant}**. Разом: **{combined['score']}/{combined['max-score']}**.", "",
              "| Лабораторна робота | Файл | Правильних результатів |", "| --- | --- | --- |"]
    for lab, result in zip(pilots, native):
        report.append(f"| №{lab} | `{LAB_FILES[lab]}` | **{result['score']}/{result['max-score']}** |")
    report.extend(["", f"[Перевірена версія коду]({environment['COMMIT_URL']}) · "
                         f"[Звіт про здачу]({environment['RELEASE_URL']})", ""])
    for lab in pilots:
        report.extend([reports[lab], ""])
    return combined, "\n".join(report)


def main() -> int:
    here = Path(__file__).resolve().parent
    workspace = Path.cwd()
    try:
        environment = dict(os.environ)
        mapping = load_variant_map(here / "public-variants.json")
        owner, variant = select_variant(environment, mapping)
        runtime = json.loads((here / "runtime.json").read_text(encoding="utf-8"))
        image = runtime.get("image", "")
        if not isinstance(image, str) or not IMAGE.fullmatch(image):
            raise ValueError("Викладач має перевірити налаштування середовища виконання")
        labs = selected_labs(environment, workspace)
        if labs:
            subprocess.run(["docker", "pull", image], check=True, timeout=180, env=clean_environment())
        with tempfile.TemporaryDirectory(prefix="nltu-c50-result-") as output:
            pilots, reports = {}, {}
            for lab in labs:
                lab_output = Path(output) / f"lab{lab}"
                completed = subprocess.run(
                    [sys.executable, "-I", str(here / "grader.py"), "--source", str(workspace / LAB_FILES[lab]),
                     "--lab", str(lab), "--variant", str(variant), "--output", str(lab_output), "--image", image],
                    check=False, timeout=300, env=clean_environment(),
                )
                if completed.returncode not in (0, 1):
                    raise ValueError("Перевірку перервано. Зверніться до викладача")
                pilots[lab] = json.loads((lab_output / "result.json").read_text(encoding="utf-8"))
                reports[lab] = (lab_output / "report.md").read_text(encoding="utf-8")
            result, report = combine_results(pilots, reports, environment, owner, variant)
            for name in ("result.json", "release-body.md"):
                destination = workspace / name
                if destination.exists() or destination.is_symlink():
                    destination.unlink()
            (workspace / "result.json").write_text(
                json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
            (workspace / "release-body.md").write_text(report, encoding="utf-8")
            print(f"Варіант {variant}: правильних результатів {result['score']} з {result['max-score']}")
        return 0
    except (OSError, ValueError, KeyError, subprocess.SubprocessError, urllib.error.URLError) as error:
        print(f"Не вдалося перевірити роботу: {str(error)[:250]}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
