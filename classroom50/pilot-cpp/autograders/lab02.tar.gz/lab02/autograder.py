"""Native Classroom 50 adapter for formative C++ Lab 02 numerical checks.

Install beside grader.py, runtime.json and public-variants.json in the published
assignment bundle. This file is teacher code, never copied from student source.
"""

from __future__ import annotations

from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request


SCHEMA = "classroom50/result/v1"
MAP_SCHEMA = "nltu.classroom50-public-variants.v1"
LOGIN = re.compile(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?")
IMAGE = re.compile(r"gcc:[A-Za-z0-9_.-]+@sha256:[a-f0-9]{64}")


def load_variant_map(path: Path) -> dict[str, int]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if (not isinstance(data, dict) or set(data) != {"schema", "variants_by_github_id"}
            or data.get("schema") != MAP_SCHEMA):
        raise ValueError("Unsupported public variant-map schema")
    mapping = data.get("variants_by_github_id")
    if not isinstance(mapping, dict) or not mapping:
        raise ValueError("An explicit public numeric-ID-to-variant map is required")
    for user_id, variant in mapping.items():
        if not re.fullmatch(r"[1-9][0-9]*", user_id) or type(variant) is not int or variant not in (1, 2):
            raise ValueError("Variant map must contain positive numeric IDs and variants 1 or 2")
    return mapping


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, newurl):
        raise ValueError("GitHub identity lookup unexpectedly redirected")


def resolve_owner_id(owner: str) -> int:
    """Read the source repository owner's account; never use the rerun actor."""
    if not LOGIN.fullmatch(owner):
        raise ValueError("Missing or invalid individual repository owner")
    request = urllib.request.Request(
        "https://api.github.com/users/" + owner,
        headers={"Accept": "application/vnd.github+json", "User-Agent": "NLTU-C50-pilot",
                 "X-GitHub-Api-Version": "2022-11-28"},
    )
    # No teacher service token is needed. A failed/rate-limited read stops the
    # run rather than selecting a default variant. This is enough for a demo.
    with urllib.request.build_opener(NoRedirect()).open(request, timeout=15) as response:
        payload = response.read(65537)
    if len(payload) > 65536:
        raise ValueError("GitHub identity response exceeded its limit")
    account = json.loads(payload)
    if (account.get("type") != "User" or not isinstance(account.get("login"), str)
            or account["login"].casefold() != owner.casefold()
            or type(account.get("id")) is not int or account["id"] <= 0):
        raise ValueError("GitHub did not confirm this individual owner")
    return account["id"]


def select_variant(environment: dict[str, str], mapping: dict[str, int], resolver=resolve_owner_id) -> tuple[str, int]:
    if environment.get("ASSIGNMENT_TYPE") != "individual":
        raise ValueError("This pilot supports individual assignments only")
    owner = environment.get("OWNER") or environment.get("USERNAME", "")
    username = environment.get("USERNAME")
    if username and owner.casefold() != username.casefold():
        raise ValueError("OWNER and USERNAME disagree")
    if not LOGIN.fullmatch(owner):
        raise ValueError("Missing or invalid individual owner")
    user_id = resolver(owner)
    if type(user_id) is not int or str(user_id) not in mapping:
        raise ValueError("This GitHub account has no assigned variant; contact the instructor")
    return owner, mapping[str(user_id)]


def to_classroom_result(pilot: dict, environment: dict[str, str], owner: str, variant: int) -> dict:
    if pilot.get("schema") != "nltu.pilot-result.v1" or pilot.get("variant_id") != variant:
        raise ValueError("Grader result does not match the expected contract and variant")
    if pilot.get("infrastructure_error") is True:
        raise ValueError("Grading infrastructure failed; instructor rerun required")
    if pilot.get("status") not in ("passed", "failed", "compile_error", "execution_error"):
        raise ValueError("Unknown grading status")
    total, passed, checks = pilot.get("total"), pilot.get("passed"), pilot.get("checks")
    if (type(total) is not int or not 1 <= total <= 100 or type(passed) is not int
            or not isinstance(checks, list) or len(checks) > total):
        raise ValueError("Invalid numerical check counts")
    tests = []
    for index, check in enumerate(checks):
        if not isinstance(check, dict) or type(check.get("passed")) is not bool:
            raise ValueError("Invalid numerical check")
        for key in ("input", "expected", "actual"):
            value = check.get(key)
            if key == "actual" and value is None:
                continue
            if type(value) not in (int, float) or not math.isfinite(value):
                raise ValueError("Invalid numerical check value")
        tests.append({
            "test-name": f"Variant {variant}: input {check['input']:g}",
            "passed": check["passed"], "score": int(check["passed"]), "max-score": 1,
            "input": check["input"], "expected": check["expected"], "actual": check.get("actual"),
            "detail": str(check.get("detail", ""))[:500], "purpose": "Formative practice point",
        })
    if passed != sum(test["score"] for test in tests):
        raise ValueError("Grader count and numerical outcomes disagree")
    if pilot["status"] == "passed" and passed != total:
        raise ValueError("Passing status has incomplete checks")
    while len(tests) < total:
        tests.append({"test-name": f"Variant {variant}: numerical case {len(tests) + 1} (not run)",
                      "passed": False, "score": 0, "max-score": 1,
                      "detail": "No numerical result; inspect the compilation or execution feedback.",
                      "purpose": "Formative practice point"})
    required = ("CLASSROOM", "ASSIGNMENT", "SUBMISSION_TAG", "COMMIT_URL", "RELEASE_URL")
    if any(not environment.get(key) for key in required):
        raise ValueError("Classroom 50 did not provide the required submission identity")
    if not environment["SUBMISSION_TAG"].startswith("submit/"):
        raise ValueError("Expected a native submit/ tag")
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return {
        "schema": SCHEMA, "classroom": environment["CLASSROOM"], "assignment": environment["ASSIGNMENT"],
        "assignment_type": "individual", "owner": owner, "submission": environment["SUBMISSION_TAG"],
        "commit": environment["COMMIT_URL"], "release": environment["RELEASE_URL"],
        "review": environment.get("REVIEW_URL") or environment["COMMIT_URL"],
        # The native runner replaces these with its submission/grade times.
        "datetime": now, "graded_at": now, "score": passed, "max-score": total, "tests": tests,
    }


def clean_environment() -> dict[str, str]:
    # Docker host access belongs only to the trusted grader process. Student
    # containers receive no environment credentials or Docker socket.
    keys = ("PATH", "HOME", "TMPDIR", "TEMP", "TMP", "SYSTEMROOT", "DOCKER_HOST",
            "DOCKER_CONTEXT", "DOCKER_CONFIG", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH")
    return {key: os.environ[key] for key in keys if key in os.environ}


def main() -> int:
    here = Path(__file__).resolve().parent
    workspace = Path.cwd()
    try:
        mapping = load_variant_map(here / "public-variants.json")
        owner, variant = select_variant(dict(os.environ), mapping)
        runtime = json.loads((here / "runtime.json").read_text(encoding="utf-8"))
        image = runtime.get("image", "")
        if not isinstance(image, str) or not IMAGE.fullmatch(image):
            raise ValueError("The teacher runtime must specify a pinned gcc image digest")
        if (workspace / "src").is_symlink() or (workspace / "src/main.cpp").is_symlink():
            raise ValueError("The submitted src/main.cpp and src directory must not be symbolic links")
        # Pull the teacher-selected image before untrusted code is staged. The
        # worker itself runs with --pull=never and has no container network.
        subprocess.run(["docker", "pull", image], check=True, timeout=180, env=clean_environment())
        with tempfile.TemporaryDirectory(prefix="nltu-c50-result-") as output:
            completed = subprocess.run(
                [sys.executable, "-I", str(here / "grader.py"), "--source", str(workspace / "src/main.cpp"),
                 "--variant", str(variant), "--output", output, "--image", image],
                check=False, timeout=300, env=clean_environment(),
            )
            if completed.returncode not in (0, 1):
                raise ValueError("Grader process did not complete normally")
            pilot = json.loads((Path(output) / "result.json").read_text(encoding="utf-8"))
            result = to_classroom_result(pilot, dict(os.environ), owner, variant)
            # Replace student-created paths without following symlinks.
            for name in ("result.json", "release-body.md"):
                destination = workspace / name
                if destination.exists() or destination.is_symlink():
                    destination.unlink()
            (workspace / "result.json").write_text(
                json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
            report = (Path(output) / "report.md").read_text(encoding="utf-8")
            note = ("# Classroom 50 practice result\n\n"
                    "Each numerical check is one practice point. This is not an official lab mark.\n\n"
                    "The instructor still reviews flowcharts, reports, student tests and the oral defense.\n\n")
            (workspace / "release-body.md").write_text(note + report, encoding="utf-8")
            print(f"Formative variant {variant}: {result['score']}/{result['max-score']} practice points")
        # Native C50 distinguishes completed failing checks from infrastructure
        # errors by this exit code. The runner derives pass/fail from result.json.
        return 0
    except (OSError, ValueError, KeyError, subprocess.SubprocessError, urllib.error.URLError) as error:
        print(f"Classroom 50 pilot could not grade: {str(error)[:250]}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
