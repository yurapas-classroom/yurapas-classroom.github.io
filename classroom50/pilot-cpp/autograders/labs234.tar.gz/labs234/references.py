"""Trusted reference generator. No student code and no expression evaluation."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

LAB02_INPUTS = {
    1: [5.8, 5.8001, 6.0, 6.25, 7.0, 7.5, 8.0, 9.0, 10.0, 10.5999, 10.6],
    2: [0.4, 0.4001, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.5, 6.2999, 6.3],
}
LAB03_INPUTS = [1, 2, 3, 4, 5, 7, 10, 16, 25, 50, 100]
LAB04_INPUTS = [
    [0], [7], [-7], [1, 2, 3], [-1, -2, -3], [5, -5, 0],
    [-100, 100], [4, 4, 4, 4], [0, 0, 0],
    [9, -2, 3, 9, 0], list(range(-10, 10)),
]


def reference(lab: int, variant: int, values: list[float | int]) -> float | int:
    if variant not in (1, 2) or lab not in (2, 3, 4):
        raise ValueError("Unknown lab or variant")
    if lab == 2:
        x, = values
        lo, hi = (5.8, 10.6) if variant == 1 else (0.4, 6.3)
        if not math.isfinite(x) or not lo <= x <= hi:
            raise ValueError("Input is outside the declared domain")
        if variant == 1:
            return (math.exp(math.sin(x)) + (17.3 + x) ** 0.25) / math.log(0.36 * x) ** 3
        return (math.log(1.85 * x) ** 4 + 0.85) / (46 + 1.85 * x ** 3) ** (1 / 3)
    if lab == 3:
        n, = values
        if not isinstance(n, int) or not 1 <= n <= 100:
            raise ValueError("n must be an integer in [1, 100]")
        return n * (n + 1) // 2 if variant == 1 else n * (n + 1) * (2 * n + 1) // 6
    if not 1 <= len(values) <= 20 or any(not isinstance(x, int) or not -100 <= x <= 100 for x in values):
        raise ValueError("Array must contain 1..20 integers in [-100, 100]")
    return sum(values) if variant == 1 else max(values)


def generate_cases(lab: int, variant: int) -> list[dict]:
    if variant not in (1, 2) or lab not in (2, 3, 4):
        raise ValueError("Unknown lab or variant")
    values_list = ([[x] for x in LAB02_INPUTS[variant]] if lab == 2 else
                   [[n] for n in LAB03_INPUTS] if lab == 3 else LAB04_INPUTS)
    cases = []
    for index, values in enumerate(values_list, 1):
        input_text = (str(len(values)) + "\n" if lab == 4 else "") + " ".join(map(str, values)) + "\n"
        cases.append({"id": f"lab{lab:02d}-v{variant}-{index:02d}",
                      "input": input_text, "expected": reference(lab, variant, values)})
    return cases


def generate_package() -> dict:
    return {"schema": "course-tests.v1", "version": "2026-10-04.1",
            "labs": {str(lab): {str(v): generate_cases(lab, v) for v in (1, 2)} for lab in (2, 3, 4)}}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("tests.generated.json"))
    args = parser.parse_args()
    args.output.write_text(json.dumps(generate_package(), indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(f"Generated 66 cases: {args.output}")
